# Using Artifacts

- Build and upload binaries for windows and linux
- Download and test binaries on both platforms
